declare module "./fix-app-issues" {
  export const initializeClickabilityFixes: () => void;
}
